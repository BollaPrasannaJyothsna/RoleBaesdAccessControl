package com.thiruacademy.service;

import com.thiruacademy.entity.UserInfo;

public interface UserInfoService {
	public String addUser(UserInfo userInfo);
}
